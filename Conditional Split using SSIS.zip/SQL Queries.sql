
USE pubs
GO
--Q.6. Show the sql to find all the titles with more than one author
SELECT 
		ti.title_id
		, ti.title
		, COUNT(ta.au_id) AS 'Number of Authors'

FROM titles AS ti
LEFT JOIN titleauthor AS ta ON ti.title_id=ta.title_id
GROUP BY ti.title_id, ti.title
HAVING COUNT (ta.au_id)> 1

--Q.7. Show the sql to show all the authors with more than one book
SELECT 
		CONCAT_WS(' ',au.au_fname, au.au_lname) AS 'Author Name'
		, au.au_id AS 'Author ID'
		, COUNT (ta.title_id) AS 'Number of Books'
FROM authors AS au 
LEFT JOIN titleauthor AS ta ON au.au_id = ta.au_id
GROUP BY au.au_fname, au.au_lname, au.au_id
HAVING COUNT (ta.title_id)>1

--Q.8. Show the sql to show the publishers with no titles
SELECT p.pub_name AS 'Publisher' 
FROM publishers AS p 
WHERE p.pub_id NOT IN (SELECT DISTINCT pub_id FROM titles)
